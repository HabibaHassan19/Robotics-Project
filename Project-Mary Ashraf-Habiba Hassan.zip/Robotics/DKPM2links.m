function [x,y]=DKPM2links(L1,L2,q1min,q1max,q2min,q2max,q1,q2)
%{
    fprintf('q1 is from %f\n ', q1min);
    fprintf('to %f\n ', q1max);
    fprintf('q2 is from %f\n ', q2min);
    fprintf('to %f\n ', q2max);
%}
    if q1<q1min || q1>q1max
        disp('Error! Angle q1 is out of range!');
    elseif q2<q2min || q2>q2max
        disp ('Error! Angle q2 is out of range!');
    else 
        x= L1*cos(q1*(pi/180))+ L2*cos((q1+q2)*(pi/180));
        y=L1*sin(q1*(pi/180))+L2*sin((q1+q2)*(pi/180));
    end
end