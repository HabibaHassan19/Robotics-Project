function[WA]=Jacobian_2link(l1,l2,q1min,q1max,q2min,q2max)
WA=l1*l2*(cosd(q2min)-cosd(q2max))*((q1max-q1min)*(pi/180));
end