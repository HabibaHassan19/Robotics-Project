function [valid,q1,q2] = IKPM_2link(X,Y,l1,l2,q1min,q1max,q2min, q2max)
%IKPM 2 link
valid=true;
q2=(acos((X^2+Y^2-l1^2-l2^2)/(2* l1*l2))*(180/pi));
if q2>q2max || q2<q2min
    q2=-1*q2;
end
sq1=(l1*Y+l2*Y*cosd(q2)-l2*X*sind(q2))/(X^2+Y^2);
cq1=(l1*X+l2*Y*sind(q2)+l2*X*cosd(q2))/(X^2+Y^2);
q1=atan2d(sq1,cq1);
tempX=l1*cosd(q1)+l2*cosd(q1+q2);
%if tempX ~= X
   % q1=q1+180;
%end
if q1>q1max || q1<q1min
    valid=false;
elseif q2>q2max || q2<q2min
      valid=false;
end