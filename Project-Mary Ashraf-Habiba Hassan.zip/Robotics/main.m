clear
clc
close all
disp('Choose:');
disp('Enter (2) to choose 2-link robot');
disp('Enter (3) to choose 3-link robot');
NoOfLinks=input('Enter your choice: ');
while NoOfLinks~=2
    if NoOfLinks==3
        break
    end
    disp('Invalid input. Please enter either (2) to choose 2-link robot or (3) to choose 3 link robot.')
    NoOfLinks=input('Enter your choice: ');
end  
if NoOfLinks==2
    clc
    disp('Please input the robot data.');
    disp('Enter the links lengths:');
    l1=input('Enter l1: ');
    l2=input('Enter l2: ');
    disp('Enter angles ranges:');
    q1min=input('Q1 is from -> ');
    q1max=input('to -> ');
    q2min=input('Q2 is from -> ');
    q2max=input('to -> ');
    UserInput=0;
    while UserInput ~=8
        clc
        disp('Choose:');
        disp('1)DKPM ');
        disp('2)IKPM ');
        disp('3)Calculate Working Area ');
        disp('4) Plot Working Area ');
        disp('5) Plot an anti-clockwise outer path of Working Area ');
        disp('6) Robot Arm Animation ')
        disp('7) Straight Line Trajectory Robot Simulation ')
        disp('8) Exit the program ')
        UserInput=input('Enter your choice: ');
        if UserInput == 1
            clc
            disp('Please enter the required data:');
            q1=input('Enter q1 in degrees = ');
            q2=input('Enter q2 in degrees = ');
            [X,Y]=DKPM2links(l1,l2,q1min,q1max,q2min,q2max,q1,q2);
            fprintf('X = %f unit, Y= %f unit \n',X,Y)
            Pause=input('Press enter to continue');
            
        elseif UserInput == 2
            clc
            disp('Please enter the required data:');
            X=input('Enter X = ');
            Y=input('Enter Y = ');
            [valid,q1,q2] = IKPM_2link(X,Y,l1,l2,q1min,q1max,q2min, q2max);
            if valid
                fprintf('q1 = %f�, q2 = %f� \n',q1,q2);
            else
                disp('Invalid inputs. Angles are out of range.')
            end
            Pause=input('Press enter to continue');
            
        elseif UserInput == 3
            clc
            disp('Choose: ');
            disp('1) Calculate the Exact Working Area ');
            disp('2) Calculate the approximate Working Area ');
            disp('3) Calculate % of error ');
            choice=input('Please enter your choice: ');
            if choice == 1
                [WA]=Jacobian_2link(l1,l2,q1min,q1max,q2min,q2max);
                fprintf('WA = %f unit^2 \n',WA);
            elseif choice == 2
                [WA]=GreenTheorem_2link(l1,l2,q1min,q1max,q2min,q2max);
                fprintf('WA = %f unit^2 \n',WA);
            elseif choice == 3
                [WAExact]=Jacobian_2link(l1,l2,q1min,q1max,q2min,q2max);
                [WAApp]=GreenTheorem_2link(l1,l2,q1min,q1max,q2min,q2max);
                Error= ((WAExact-WAApp)/WAExact)*100;
                fprintf('percentage of error = %f percent\n',Error);
            end
            Pause=input('Press enter to continue');
            
        elseif UserInput == 4
            clc
            WAPlot_2link(l1,l2,q1min,q1max,q2min,q2max);
            Pause=input('Press enter to continue');
            
        elseif UserInput == 5
            clc
            PathPlot_2link(l1,l2,q1min,q1max,q2min,q2max);
            Pause=input('Press enter to continue');
            
        elseif UserInput == 6
            clc
            RobotAnimation2Links(l1,l2,q1min,q1max,q2min,q2max);
            Pause=input('Press enter to continue');
            
        elseif UserInput == 7
            clc
            disp('Please enter the following data: ');
            X1=input('X1 = ');
            Y1=input('Y1 = ');
            X2=input('X2 = ');
            Y2=input('Y2 = ');
            StLineTrj_2Links(l1,l2,q1min,q1max,q2min,q2max,X1,Y1,X2,Y2);
            Pause=input('Press enter to continue');

        else
            break;
        end
    end

elseif NoOfLinks==3 
    clc
    disp('Please input the robot data.');
    disp('Enter the links lengths:');
    l1=input('Enter L1: ');
    l2=input('Enter L2: ');
    l3=input('Enter L3: ');
    disp('Enter angles ranges:');
    q1min=input('Q1 is from -> ');
    q1max=input('to -> ');
    q2min=input('Q2 is from -> ');
    q2max=input('to -> ');
    q3min=input('Q3 is from -> ');
    q3max=input('to -> ');
    UserInput=0;
    while UserInput ~=8
        clc
        disp('Choose:');
        disp('1)DKPM ');
        disp('2)IKPM ');
        disp('3)Calculate Working Area ');
        disp('4) Plot Working Area ');
        disp('5) Plot an anti-clockwise outer path of Working Area ');
        disp('6) Robot Arm Animation ')
        disp('7) Straight Line Trajectory Robot Simulation ')
        disp('8) Exit the program ')
        UserInput=input('Enter your choice: ');
        if UserInput == 1
            clc
            disp('Please enter the required data:');
            q1=input('Enter q1 in degrees = ');
            q2=input('Enter q2 in degrees = ');
            q3=input('Enter q3 in degrees = ');
            if q1 < q1min || q1 > q1max || q2 < q2min || q2 > q2max || q3 < q3min || q3 > q3max
                disp('One of the angles is out of range');
            else
                [x,y,phi]=DKPM_3link(q1, q2, q3, l1, l2, l3);
                fprintf('X = %f unit, Y= %f unit, phi= %f� \n',x,y,phi);
                Pause=input('Press enter to continue');
            end
            
        elseif UserInput == 2
            clc
            disp('Choose: ');
            disp('1)Calculate IKPM using phi entered manually ');
            disp('2)Calculate IKPM using minimum valid phi ');
            choice=input('Please enter your choice: ');
            clc
            disp('Please enter the required data:');
            X=input('Enter X = ');
            Y=input('Enter Y = ');
            if choice ==1
                Phi=input('Enter phi = ');
                [valid, twoSol, q1,q2,q3,q1bar,q2bar,q3bar] = IKPM_3link(X, Y, Phi, l1, l2, l3,q1min, q1max, q2min, q2max,q3min, q3max);
                if valid
                    if twoSol
                        disp('There are two solutions: ');
                        fprintf('q1 = %f�, q2 = %f�, q3 = %f� \n',q1,q2,q3);
                        fprintf('q1 = %f�, q2 = %f�, q3 = %f� \n',q1bar,q2bar,q3bar);
                    else
                        disp('There is one solution: ');
                        fprintf('q1 = %f�, q2 = %f�, q3 = %f� \n',q1,q2,q3);
                    end
                else
                    disp('Invalid phi');
                end
            elseif choice==2
                [q1,q2,q3] = IKPM_MinPhi(X, Y, l1, l2, l3,q1min, q1max, q2min, q2max,q3min, q3max);
                fprintf('q1 = %f�, q2 = %f�, q3 = %f� \n',q1,q2,q3);
                phi=q1+q2+q3;
                fprintf('phi = %f�\n',phi);
            end
            Pause=input('Press enter to continue');
            
        elseif UserInput == 3
            clc
            [WA]=GreenTheorem_3Links(l1,l2,l3,q1min,q1max,q2min,q2max,q3min,q3max);
            fprintf('WA = %f unit^2 \n',WA);
            Pause=input('Press enter to continue');
            
        elseif UserInput == 4
            clc
            WAPlot_3link(l1,l2,l3,q1min,q1max,q2min,q2max,q3min,q3max);
            Pause=input('Press enter to continue');
            
        elseif UserInput == 5
            clc
            PathPlot_3link(l1,l2,l3,q1min,q1max,q2min,q2max,q3min,q3max);
            Pause=input('Press enter to continue');
            
        elseif UserInput == 6
            clc
            RobotAnimation(l1,l2,l3,q1min,q1max,q2min,q2max,q3min,q3max);
            Pause=input('Press enter to continue');
            
        elseif UserInput == 7
            clc
            disp('Please enter the following data: ');
            X1=input('X1 = ');
            Y1=input('Y1 = ');
            X2=input('X2 = ');
            Y2=input('Y2 = ');
            StLineTrj_3Links(l1,l2,l3,q1min,q1max,q2min,q2max,q3min,q3max,X1,Y1,X2,Y2);
            Pause=input('Press enter to continue');

        else
            break;
        end
    end
end