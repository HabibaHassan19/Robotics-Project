function [WA]=GreenTheorem_3Links(L1,L2,L3,q1min,q1max,q2min,q2max,q3min,q3max)

X=linspace(0,L1+L2+L3,600);
Y=linspace(0,L1+L2+L3,600);

WA=0;
MissingPath=false;
q1=linspace(q1min,q1max,100);
q2=q2min;
q3=q3min;

for i = 1:100
    [X(i), Y(i), phi] = DKPM_3link(q1(i),q2,q3,L1,L2,L3);
end
if L1 < (L2+L3)
    
    q2 = linspace(q2min, q2max, 100);
    q1 = q1max;
    q3 = q3min;
    for i = 1:100
        [X(i+100), Y(i+100), phi] = DKPM_3link(q1,q2(i),q3,L1,L2,L3);
    end
    
    q3 = linspace(q3min, q3max, 100);
    q2 = q2max;
    q1 = q1min;
    for i = 1:100
        [X(i+300), Y(i+300), phi] = DKPM_3link(q1,q2,q3(i),L1,L2,L3);
    end
    x1 = 100;
    y1 = 100;
    for i = 1 : 100
        for j = 1: 100
            if round(X(i+100),1) == round(X(j+300),1) &&  round(Y(i+100),1) == round(Y(j+300),1)
                x1 = X(i+100);
                y1 = Y(i+100);
                break
            end
        end
    end
    if x1 ~= 100 %there will be only 5 paths
        MissingPath=true;
        q2 = atan2d(y1,(x1 + L1));
        q2 = q2max + q2;
        
        q3 = atan2d(y1,(L1-L2-x1));
        q3 = -1 * q3;
    end
    
    q2 = linspace(q2min, q2, 100);
    q1 = q1max;
    q3 = q3min;
    for i = 1:100
        [X(i+100), Y(i+100), phi] = DKPM_3link(q1,q2(i),q3,L1,L2,L3);
    end
    
    q3 = linspace(q3, q3max, 100);
    q2 = q2max;
    q1 = q1min;
    for i = 1:100
        [X(i+300), Y(i+300), phi] = DKPM_3link(q1,q2,q3(i),L1,L2,L3);
    end
    
else % L1 >= L2 + L3
    q2 = linspace(q2min, q2max, 100);
    q1 = q1max;
    q3 = q3min;
    for i = 1:100
        [X(i+100), Y(i+100), phi] = DKPM_3link(q1,q2(i),q3,L1,L2,L3);
    end
    
    q1 = linspace(q1max, q1min, 100);
    q2 = q2max;
    q3 = q3min;
    for i = 1:100
        [X(i+200), Y(i+200), phi] = DKPM_3link(q1(i),q2,q3,L1,L2,L3);
    end
    
    q3 = linspace(q3min, q3max, 100);
    q2 = q2max;
    q1 = q1min;
    for i = 1:100
        [X(i+300), Y(i+300), phi] = DKPM_3link(q1,q2,q3(i),L1,L2,L3);
    end
end

q2 = linspace(q2max, q2min, 100);
q1 = q1min;
q3 = q3max;
for i = 1:100
    [X(i+400), Y(i+400), phi] = DKPM_3link(q1,q2(i),q3,L1,L2,L3);
end


q3 = linspace(q3max, q3min, 100);
q1 = q1min;
q2 = q2min;
for i = 1:100
    [X(i+500), Y(i+500), phi] = DKPM_3link(q1,q2,q3(i),L1,L2,L3);
end

for i=1:599
    if MissingPath
        if i<201 || i>300 %to exclude the missing path
             WA=WA+(X(i+1)+X(i))*(Y(i+1)-Y(i));
        end
    else
         WA=WA+(X(i+1)+X(i))*(Y(i+1)-Y(i));
    end
end

WA=WA*0.5;
end