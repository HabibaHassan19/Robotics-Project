function [] = PathPlot_3link(L1, L2, L3, q1min, q1max, q2min, q2max,q3min, q3max)

Max = L1 + L2 + L3;
axis([-1*(Max+1) (Max+1) -1*(Max+1) (Max+1)])
grid on
hold on

X = linspace(0,Max,600);
Y = linspace(0,Max,600);

Q1 = linspace(q1min, q1max, 100);
Q2 = q2min;
Q3 = q3min;
for i = 1:100
    [X(i), Y(i), phi] = DKPM_3link(Q1(i),Q2,Q3,L1,L2,L3);
    plot(X(i),Y(i),'.');
    hold on
    drawnow
end
if L1 < (L2+L3)
    
    Q2 = linspace(q2min, q2max, 100);
    Q1 = q1max;
    Q3 = q3min;
    for i = 1:100
        [X(i+100), Y(i+100), phi] = DKPM_3link(Q1,Q2(i),Q3,L1,L2,L3);
    end
    
    Q3 = linspace(q3min, q3max, 100);
    Q2 = q2max;
    Q1 = q1min;
    for i = 1:100
        [X(i+300), Y(i+300), phi] = DKPM_3link(Q1,Q2,Q3(i),L1,L2,L3);
    end
    x1 = 100;
    y1 = 100;
    for i = 1 : 100
        for j = 1: 100
            if round(X(i+100),1) == round(X(j+300),1) &&  round(Y(i+100),1) == round(Y(j+300),1)
                x1 = X(i+100);
                y1 = Y(i+100);
                break
            end
        end
    end
    if x1 ~= 100
        q2 = atan2d(y1,(x1 + L1));
        q2 = q2max + q2;
        
        q3 = atan2d(y1,(L1-L2-x1));
        q3 = -1 * q3;
        Q2 = linspace(q2min, q2, 100);
        Q1 = q1max;
        Q3 = q3min;
        for i = 1:100
           [X(i+100), Y(i+100), phi] = DKPM_3link(Q1,Q2(i),Q3,L1,L2,L3);
           plot(X(i+100),Y(i+100),'.');
           hold on
           drawnow
        end
    
        Q3 = linspace(q3, q3max, 100);
        Q2 = q2max;
        Q1 = q1min;
        for i = 1:100
           [X(i+300), Y(i+300), phi] = DKPM_3link(Q1,Q2,Q3(i),L1,L2,L3);
           plot(X(i+300),Y(i+300),'.');
           hold on
           drawnow
        end
    end
else % L1 >= L2 + L3
    Q2 = linspace(q2min, q2max, 100);
    Q1 = q1max;
    Q3 = q3min;
    for i = 1:100
        [X(i+100), Y(i+100), phi] = DKPM_3link(Q1,Q2(i),Q3,L1,L2,L3);
        plot(X(i+100),Y(i+100),'.');
        hold on
        drawnow
    end
    
    Q1 = linspace(q1max, q1min, 100);
    Q2 = q2max;
    Q3 = q3min;
    for i = 1:100
        [X(i+200), Y(i+200), phi] = DKPM_3link(Q1(i),Q2,Q3,L1,L2,L3);
        plot(X(i+200),Y(i+200),'.');
        hold on
        drawnow
    end
    
    Q3 = linspace(q3min, q3max, 100);
    Q2 = q2max;
    Q1 = q1min;
    for i = 1:100
        [X(i+300), Y(i+300), phi] = DKPM_3link(Q1,Q2,Q3(i),L1,L2,L3);
        plot(X(i+300),Y(i+300),'.');
        hold on
        drawnow
    end
end

Q2 = linspace(q2max, q2min, 100);
Q1 = q1min;
Q3 = q3max;
for i = 1:100
    [X(i+400), Y(i+400), phi] = DKPM_3link(Q1,Q2(i),Q3,L1,L2,L3);
    plot(X(i+400),Y(i+400),'.');
    hold on
    drawnow
end


Q3 = linspace(q3max, q3min, 100);
Q1 = q1min;
Q2 = q2min;
for i = 1:100
    [X(i+500), Y(i+500), phi] = DKPM_3link(Q1,Q2,Q3(i),L1,L2,L3);
    plot(X(i+500),Y(i+500),'.');
    hold on
    drawnow
end