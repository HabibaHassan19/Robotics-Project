function [q1,q2,q3] = IKPM_MinPhi(X, Y, l1, l2, l3,q1min, q1max, q2min, q2max,q3min, q3max)
%gets q1,q2 and q3 using minimum valid phi
for phi = 0 :0.5: 360
    Xbar = X - l3*cosd(phi);
    Ybar = Y - l3*sind(phi);
    c2 = (Xbar^2 + Ybar^2 - l2^2 - l1^2)/(2*l1*l2);
    if c2 < -1 || c2 > 1 %invalid phi
        continue
    else
        q2 = acosd(c2);
    end
    if q2<q2min || q2 > q2max
        q2 = -1*q2;
    end
    c1=(l1*Xbar+l2*Ybar*sind(q2)+l2*Xbar*cosd(q2))/(Xbar^2+Ybar^2);
    s1=(l1*Ybar+l2*Ybar*cosd(q2)-l2*Xbar*sind(q2))/(Xbar^2+Ybar^2);
    if c1 < -1 || c1 > 1 || s1 < -1 || s1 > 1 %invalid phi
        continue
    end
    q1=atan2d(s1,c1);
    q3 = phi - q1 - q2;
    if q1>=q1min && q1<=q1max
        if q2>=q2min && q2<=q2max
            if q3>=q3min && q3<=q3max %q1, q2 and q3 are within ranges -> minimum valid phi  
                break
            end
        end
    end
end
