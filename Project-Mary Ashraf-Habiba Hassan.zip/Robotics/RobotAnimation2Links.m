function []=RobotAnimation2Links(L1,L2,q1min,q1max,q2min,q2max)
        theta1=linspace(q1min,q1max,4);
        theta2=linspace(q2min,q2max,4);
        counter=1;
        for i=1:length(theta1)
            Theta1=theta1(i);
            for j=1:length(theta2)
                Theta2=theta2(j);
                x0=0;
                y0=0;
                x1=L1*cosd(Theta1);
                y1=L1*sind(Theta1);
                x2=x1+L2*cosd(Theta2+Theta1);
                y2=y1+L2*sind(Theta2+Theta1);
                
                plot([x0,x1],[y0,y1],[x1,x2],[y1,y2],'linewidth',2)
                grid on
                axis([-20 20 -20 20])
                pause(0.1)
                m(counter)=getframe(gcf);
                counter=counter+1;
            end
        end
        movie(m)
        videofile=VideoWriter('Robot Animation of 2 links robot','uncompressed AVI');
        open(videofile)
        writeVideo(videofile,m)
        close(videofile)
end