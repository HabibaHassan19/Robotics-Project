function []=StLineTrj_3Links(L1,L2,L3,q1min,q1max,q2min,q2max,q3min,q3max,X1,Y1,X2,Y2)

x=linspace(X1,X2,100);
m=(Y2-Y1)/(X2-X1);
c=Y1-m*X1;
y=m*x+c;
Q1=linspace(0,10,100);
Q2=linspace(0,10,100);
Q3=linspace(0,10,100);
for i=1:length(Q1)
        [Q1(i),Q2(i),Q3(i)]=IKPM_MinPhi(x(i),y(i),L1,L2,L3,q1min,q1max,q2min,q2max,q3min,q3max);
end

x1=L1*cosd(Q1);
y1=L1*sind(Q1);
x2=x1+L2*cosd(Q2+Q1);
y2=y1+L2*sind(Q2+Q1);
x3=x2+L3*cosd(Q3+Q2+Q1);
y3=y2+L3*sind(Q3+Q2+Q1);

        for i=1:length(x)
            clf;
            axis([-20 20 -20 20])
            hold on
            plot(x,y,'--','color','r');
            hold on;
            x0=0;
            y0=0;
            plot([x0,x1(i)],[y0,y1(i)],[x1(i),x2(i)],[y1(i),y2(i)],[x2(i),x3(i)],[y2(i),y3(i)],'linewidth',3)
            hold on;
            grid on
            plot(x3(i),y3(i),'color','y');
            hold on;
            drawnow
            pause(0.1)
        end
end
       