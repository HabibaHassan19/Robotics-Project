function [X,Y, Phi] = DKPM_3link(q1, q2, q3, l1, l2, l3)
%DKPM 3 link
X = l1*cosd(q1) + l2*cosd(q1 + q2) + l3*cosd(q1+q2+q3);
Y =  l1*sind(q1) + l2*sind(q1 + q2) + l3*sind(q1+q2+q3); 
Phi = q1 + q2 + q3;