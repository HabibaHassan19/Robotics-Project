function[]=PathPlot_2link(l1,l2,q1min,q1max,q2min,q2max)
max=l1+l2;
axis = ([-1*(max+1) (max+1) -1*(max+1) (max+1)]);
grid on 
hold on
title('Path Plot of 2 links robot')

X=linspace(0,max,400);
Y=linspace(0,max,400);
q1=linspace(q1min,q1max,100);
q2=q2min;
for i=1:100
    X(i)=l1*(cos((q1(i))*(pi/180)))+l2*(cos((q1(i)+q2)*(pi/180)));
    Y(i)=l1*(sin((q1(i))*(pi/180)))+l2*(sin((q1(i)+q2)*(pi/180)));
    plot(X(i),Y(i),'.');
    hold on
    drawnow
end

q2=linspace(q2min,q2max,100);
q1=q1max;
for i=1:100
    X(i+100)=l1*(cos((q1)*(pi/180)))+l2*(cos((q1+q2(i))*(pi/180)));
    Y(i+100)=l1*(sin((q1)*(pi/180)))+l2*(sin((q1+q2(i))*(pi/180)));
    plot(X(i+100),Y(i+100),'.');
    hold on
    drawnow
end
q1=linspace(q1max,q1min,100);
q2=q2max;
for i=1:100
    X(i+200)=l1*(cos((q1(i))*(pi/180)))+l2*(cos((q1(i)+q2)*(pi/180)));
    Y(i+200)=l1*(sin((q1(i))*(pi/180)))+l2*(sin((q1(i)+q2)*(pi/180)));
    plot(X(i+200),Y(i+200),'.');
    hold on
    drawnow
end
q2=linspace(q2max,q2min,100);
q1=q1min;
for i=1:100
    X(i+300)=l1*(cos((q1)*(pi/180)))+l2*(cos((q1+q2(i))*(pi/180)));
    Y(i+300)=l1*(sin((q1)*(pi/180)))+l2*(sin((q1+q2(i))*(pi/180)));
    plot(X(i+300),Y(i+300),'.');
    hold on
    drawnow
end
end