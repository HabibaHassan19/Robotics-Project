function []=RobotAnimation(L1,L2,L3,q1min,q1max,q2min,q2max,q3min,q3max)
        theta1=linspace(q1min,q1max,4);
        theta2=linspace(q2min,q2max,4);
        theta3=linspace(q3min,q3max,4);
        counter=1;
        for i=1:length(theta1)
            Theta1=theta1(i);
            for j=1:length(theta2)
                Theta2=theta2(j);
                for k=1:length(theta3)
                    Theta3=theta3(k);
                    x0=0;
                    y0=0;
                    x1=L1*cosd(Theta1);
                    y1=L1*sind(Theta1);
                    x2=x1+L2*cosd(Theta2+Theta1);
                    y2=y1+L2*sind(Theta2+Theta1);
                    x3=x2+L3*cosd(Theta3+Theta2+Theta1);
                    y3=y2+L3*sind(Theta3+Theta2+Theta1);
                
                plot([x0,x1],[y0,y1],[x1,x2],[y1,y2],[x2,x3],[y2,y3],'linewidth',3)
                grid on
                axis([-20 20 -20 20])
                pause(0.1)
                m(counter)=getframe(gcf);
                counter=counter+1;
                end
            end
        end
        movie(m)
        videofile=VideoWriter('Robot Animation of 3 links robot','uncompressed AVI');
        open(videofile)
        writeVideo(videofile,m)
        close(videofile)

    
                