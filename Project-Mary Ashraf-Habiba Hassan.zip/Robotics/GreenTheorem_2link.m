function [WA]=GreenTheorem_2link(l1,l2,q1min,q1max,q2min,q2max)
%WA using green's theorem (2 link)
X=linspace(0,l1+l2,400);
Y=linspace(0,l1+l2,400);
WA=0;
q1=linspace(q1min,q1max,100);
q2=q2min;
for i=1:100
    X(i)=l1*(cos((q1(i))*(pi/180)))+l2*(cos((q1(i)+q2)*(pi/180)));
    Y(i)=l1*(sin((q1(i))*(pi/180)))+l2*(sin((q1(i)+q2)*(pi/180)));
end

q2=linspace(q2min,q2max,100);
q1=q1max;
for i=1:100
    X(i+100)=l1*(cos((q1)*(pi/180)))+l2*(cos((q1+q2(i))*(pi/180)));
    Y(i+100)=l1*(sin((q1)*(pi/180)))+l2*(sin((q1+q2(i))*(pi/180)));
end
q1=linspace(q1max,q1min,100);
q2=q2max;
for i=1:100
    X(i+200)=l1*(cos((q1(i))*(pi/180)))+l2*(cos((q1(i)+q2)*(pi/180)));
    Y(i+200)=l1*(sin((q1(i))*(pi/180)))+l2*(sin((q1(i)+q2)*(pi/180)));
end
q2=linspace(q2max,q2min,100);
q1=q1min;
for i=1:100
    X(i+300)=l1*(cos((q1)*(pi/180)))+l2*(cos((q1+q2(i))*(pi/180)));
    Y(i+300)=l1*(sin((q1)*(pi/180)))+l2*(sin((q1+q2(i))*(pi/180)));
end

for i=1:399
     WA=WA+(X(i+1)+X(i))*(Y(i+1)-Y(i));
end

WA=WA*0.5;
end