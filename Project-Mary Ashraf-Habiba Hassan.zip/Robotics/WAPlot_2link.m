function []=WAPlot_2link(l1,l2,q1min,q1max,q2min,q2max)
max=l1+l2;
axis = ([-1*(max+1) (max+1) -1*(max+1) (max+1)]);
hold on
q1=linspace(q1min,q1max,400);
q2=linspace(q2min,q2max,400);
for i=1:length(q1)
    X=l1*(cos((q1(i))*(pi/180)))+l2*(cos((q1(i)+q2)*(pi/180)));
    Y=l1*(sin((q1(i))*(pi/180)))+l2*(sin((q1(i)+q2)*(pi/180)));
    grid on
    hold on
    plot(X,Y,'b')
    title('Working Area of 2 links robot')
end
end
    