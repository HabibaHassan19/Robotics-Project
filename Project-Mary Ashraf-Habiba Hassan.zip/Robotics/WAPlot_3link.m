function[]=WAPlot_3link(l1,l2,l3,q1min,q1max,q2min,q2max,q3min,q3max)
max=l1+l2+l3;
axis = ([-1*(max+1) (max+1) -1*(max+1) (max+1)]);
grid on
hold on
q1=linspace(q1min,q1max,65);
q2=linspace(q2min,q2max,65);
q3=linspace(q3min,q3max,65);
for i=1:length(q1)
    for j=1:length(q2)
        [X,Y,Phi]=DKPM_3link(q1(i),q2(j),q3,l1,l2,l3);
        plot(X,Y,'b')
        title('Working Area of 3 links robot')
        hold on
    end
end
end